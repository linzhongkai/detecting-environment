#include "BH1750.h"
#include "stm32f10x.h"
#include "mydelay.h"

void GPIOConfig(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_InitStruct.GPIO_Pin=sda|scl;
	
	GPIO_Init(GPIOB,&GPIO_InitStruct);
	
}
//��ʼ�ź�
void BH1750_Start()
{
	GPIO_SetBits(GPIOB,sda);
	GPIO_SetBits(GPIOB,scl);
	delay_5us();
	GPIO_ResetBits(GPIOB,sda);
	delay_5us();
	GPIO_ResetBits(GPIOB,scl);
}
//ֹͣ�ź�
void BH1750_Stop()
{
	GPIO_ResetBits(GPIOB,sda);
	GPIO_SetBits(GPIOB,scl);
	delay_5us();
	GPIO_SetBits(GPIOB,sda);
	delay_5us();
}
//����Ӧ���ź�
//��ڲ�����ack(0:ack,1:nack)
void BH1750_SendAck(int ack)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_InitStruct.GPIO_Pin=sda;
	GPIO_Init(GPIOB,&GPIO_InitStruct);
	
	if(ack==1)//дӦ���ź�
	{
		GPIO_SetBits(GPIOB,sda);
	}
	else if(ack==0)
	{
		GPIO_ResetBits(GPIOB,sda);
	}
	else
	{
		return;
	}
		
	GPIO_SetBits(GPIOB,scl);
	delay_5us();
	GPIO_ResetBits(GPIOB,scl);
	delay_5us();
	
}
//����Ӧ���ź�
int BH1750_RecvACK()
{
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_IPD;//���ó���������
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_InitStruct.GPIO_Pin=sda;
	GPIO_Init(GPIOB,&GPIO_InitStruct);
	
	GPIO_SetBits(GPIOB,scl);
	delay_5us();
	if(GPIO_ReadInputDataBit(GPIOB,sda)==1)//����Ӧ���ź�
		MCY=1;
	else
		MCY=0;
	GPIO_ResetBits(GPIOB,scl);
	delay_5us();
	
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_Init(GPIOB,&GPIO_InitStruct);
	
	return MCY;
}
//�����߷���һ���ֽ�����
void BH1750_SendByte(uchar dat)
{
	uchar i;
	for(i=0;i<8;i++)
	{
		if(0x80&dat)
		{
			GPIO_SetBits(GPIOB,sda);
		}
		else
		{
			GPIO_ResetBits(GPIOB,sda);
		}
		dat<<=1;
		GPIO_SetBits(GPIOB,scl);
		delay_5us();
		GPIO_ResetBits(GPIOB,scl);
		delay_5us();
	}
	BH1750_RecvACK();
}
//����һ���ֽ�����
uchar BH1750_RecvByte()
{
	uchar i;
	uchar dat=0;
	uchar bit;
	
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_IPU;//�����������
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_InitStruct.GPIO_Pin=sda;
	GPIO_Init(GPIOB,&GPIO_InitStruct);
	
	GPIO_SetBits(GPIOB,sda);
	for(i=0;i<8;i++)
	{
		dat<<=1;
		GPIO_SetBits(GPIOB,scl);
		delay_5us();
		if(SET==GPIO_ReadInputDataBit(GPIOB,sda))
		{
			bit=0x01;
		}
		else
		{
			bit=0x00;
		}
		dat|=bit;//������
		
		GPIO_ResetBits(GPIOB,scl);
		delay_5us();
	}
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_Init(GPIOB,&GPIO_InitStruct);
	return dat;
}

//BH1750д����
void Single_Write_BH1750(uchar REG_Address)
{
	BH1750_Start();
	BH1750_SendByte(SlaveAddress);
	BH1750_SendByte(REG_Address);
	BH1750_Stop();
}
//��������BH1750�ڲ�����
void Multiple_Read()
{
	uchar i;
	BH1750_Start();
	BH1750_SendByte(SlaveAddress+1);
	for(i=0;i<3;i++)
	{
		BUF[i]=BH1750_RecvByte();
		if(i==3)
		{
			BH1750_SendAck(1);
		}
		else
		{
			BH1750_SendAck(0);
		}
	}
	BH1750_Stop();
	delay_nms(5);
}
//��ʼ������
void Init_BH1750()
{
	Single_Write_BH1750(0x01);
}

