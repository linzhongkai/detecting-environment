#include "stm32f10x.h"
#ifndef DELAY_H
#define DELAY_H 
//Delay

void Delay_ms(u32 delay_time);
void Delay_us(u32 delay_time);
//void Delay_100us(u32 delay_time);

#endif
