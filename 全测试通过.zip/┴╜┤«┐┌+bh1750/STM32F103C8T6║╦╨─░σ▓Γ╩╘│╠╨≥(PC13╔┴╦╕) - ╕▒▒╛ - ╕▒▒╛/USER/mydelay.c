#include "stm32f10x.h"
#include "GPIOLIKE51.h"
#include "mydelay.h"

//��ʱ����
void delay_us()
{
	__NOP();__NOP();__NOP();__NOP();//1
	__NOP();__NOP();__NOP();__NOP();//2
	__NOP();__NOP();__NOP();__NOP();//3
	__NOP();__NOP();__NOP();__NOP();//4
	__NOP();__NOP();__NOP();__NOP();//5
	__NOP();__NOP();__NOP();__NOP();//6
	__NOP();__NOP();__NOP();__NOP();//7
	__NOP();__NOP();__NOP();__NOP();//8
	__NOP();__NOP();__NOP();__NOP();//9
	__NOP();__NOP();__NOP();__NOP();//10
	__NOP();__NOP();__NOP();__NOP();//11
	__NOP();__NOP();__NOP();__NOP();//12
	__NOP();__NOP();__NOP();__NOP();//13
	__NOP();__NOP();__NOP();__NOP();//14
	__NOP();__NOP();__NOP();__NOP();//15
	__NOP();__NOP();__NOP();__NOP();//16
	__NOP();__NOP();__NOP();__NOP();//17
	__NOP();__NOP();__NOP();__NOP();//18
	
}

void delay_5us()
{
	delay_us();
	delay_us();
	delay_us();
	delay_us();
	delay_us();
	
}

void delay_1ms()
{
	u16 j=0;
	for(j=0;j<1000;j++)
	{
		delay_us();

	}
}
void delay_nms(u16 time)
{
	u16 t=0;
	for(t=0;t<time;t++)
	{
		delay_1ms();
	}
	
}
