
#include <aiic.h>
#include <delay.h>
//--------------------------------------------------д����------------------------------------------------------
_Bool AIIC_WriteData(unsigned char Device_Addr, unsigned char Memory_Addr, unsigned char Data)
{

	if(AIIC_Reset() == 0)
		return 0;
	AIIC_Init();
	
	//��ʼ��־
	AIIC_Begin_Sign();
	//���͵�ַ
	AIIC_Send_Device_Addr(Device_Addr);
	//дλ
	AIIC_Write_Sign();
	//�ȴ�Ӧ��
	if(AIIC_WriteWaitForAnswer() == 0)
	{
		return 0;
	}
	//�����ڴ��ַ
	AIIC_Send_Memory_Addr(Memory_Addr);
	//�ȴ�Ӧ��
	if(AIIC_WriteWaitForAnswer() == 0)
	{
		return 0;
	}	
	//��������
	AIIC_InSendData(Data);
	//�ȴ���Ӧ
	if(AIIC_WriteWaitForAnswer() == 0)
	{
		return 0;
	}
	//����
	AIIC_End_Sign();

	return 1;
}

//--------------------------------------------------��ȡ����------------------------------------------------------
_Bool AIIC_ReadData(unsigned char Device_Addr, unsigned char Memory_Addr,unsigned char *My_RecData)
{
	u8 RecData=0;
	
	u8 Addr_temp=Device_Addr;
	int Count = 0;
	
	if(AIIC_Reset() == 0) //���ôӻ�IIC
		return 0;
	AIIC_Begin_Sign();//��ʼ��־
	AIIC_Send_Device_Addr(Device_Addr);//���͵�ַ
	AIIC_Write_Sign();//дλ
	if(AIIC_WriteWaitForAnswer() == 0)//�ȴ�Ӧ��
	{
		return 0;
	}
	AIIC_Send_Memory_Addr(Memory_Addr);//���ʹ洢����ַ
	if(AIIC_WriteWaitForAnswer() == 0)//�ȴ���Ӧ
	{
		return 0;
	}
	AIIC_Begin_Sign();//��ʼ��־
	AIIC_Send_Device_Addr(Addr_temp);//���͵�ַ
	AIIC_Read_Sign();//��ȡ��־
	AIIC_ReadWaitForAnswer();//�ȴ�Ӧ��

	*My_RecData = AIIC_InReadData();
	
	AIIC_NoAnswer();//��Ӧ��
	AIIC_End_Sign();//������־
	
	return 1;
}
//--------------------------------------------------��������Ӧ------------------------------------------------------
void AIIC_NoAnswer(void)
{
	SSDA_HIGH;
	IIC_RF_DELAY;
	SSCL_HIGH;
	IIC_D_DELAY;
	SSCL_LOW;
	IIC_D_DELAY;
}

//--------------------------------------------------���ȴ�Ӧ��------------------------------------------------------
_Bool AIIC_ReadWaitForAnswer(void)
{
	u32 OverTimes=0;
	
		//�ȴ���Ӧ
	SSDA_HIGH;
	IIC_RF_DELAY;
	SSCL_HIGH;
	OverTimes=0;
	IIC_D_DELAY;
	while(GET_SSDA == 1 && ++OverTimes < 72000)
		;//�ȴ���ʱ
	if(OverTimes >= 72000)
		return 0;//�ȴ�Ӧ��ʧ��
	Delay_us(100);
	SSCL_LOW;
	IIC_D_DELAY;
	SSDA_HIGH;
	IIC_RF_DELAY;
	return 1;
}
//--------------------------------------------------д�ȴ�Ӧ��------------------------------------------------------
_Bool AIIC_WriteWaitForAnswer(void)
{
	u32 OverTimes=0;
	
	SSDA_HIGH;
	IIC_RF_DELAY;
	SSCL_HIGH;
	OverTimes=0;
	IIC_D_DELAY;
	while(GET_SSDA == 1 && ++OverTimes < 72000)//�ȴ���ʱ
		;
	if(OverTimes >= 72000)//�ȴ�Ӧ��ʧ��
		return 0;
	Delay_us(100);
	SSCL_LOW;
	IIC_D_DELAY;
	OverTimes=0;
	SSDA_HIGH;
	IIC_RF_DELAY;
	while(GET_SSDA == 0 && ++OverTimes < 72000)//�ȴ���ʱ
		;
	if(OverTimes >= 72000)//�ȴ�Ӧ��ʧ��
		return 0;
	return 1;
}
//--------------------------------------------------������־------------------------------------------------------
void AIIC_End_Sign(void)
{
		//������־
	SSDA_LOW;
	IIC_RF_DELAY;
	SSCL_HIGH;
	IIC_D_DELAY;
	SSDA_HIGH;
	IIC_D_DELAY;
}
//--------------------------------------------------��ʼ��־------------------------------------------------------
void AIIC_Begin_Sign(void)
{
		//��ʼ��־
	SSCL_HIGH;
	SSDA_HIGH;
	IIC_D_DELAY;
	SSDA_LOW;
	IIC_D_DELAY;
	SSCL_LOW;
	IIC_RF_DELAY;
}
//--------------------------------------------------д��־------------------------------------------------------
void AIIC_Write_Sign(void)
{
		//дλ
	SSDA_LOW;
	IIC_RF_DELAY;
	SSCL_HIGH;
	IIC_D_DELAY;
	SSCL_LOW;
	IIC_RF_DELAY
	SSDA_HIGH;
	IIC_RF_DELAY;
}
//--------------------------------------------------����־------------------------------------------------------
void AIIC_Read_Sign(void)
{
			//��λ
	SSDA_HIGH;
	IIC_RF_DELAY;
	SSCL_HIGH;
	IIC_D_DELAY;
	SSCL_LOW;
	IIC_RF_DELAY
	SSDA_HIGH;
	IIC_RF_DELAY;
}
//--------------------------------------------------�����豸��ַ------------------------------------------------------
void AIIC_Send_Device_Addr(u8 My_Device_Addr)
{
	u8 Count;
	
	for(Count = 0;Count < 7;Count++)
	{
		if(My_Device_Addr&0x40)
		{
			SSDA_HIGH;
		}
		else
		{
			SSDA_LOW;
		}
		IIC_RF_DELAY;
		SSCL_HIGH;
		IIC_D_DELAY;
		SSCL_LOW;
		IIC_RF_DELAY;
		My_Device_Addr <<= 1;
	}
	SSDA_HIGH;
}
//--------------------------------------------------���ͼĴ�����ַ------------------------------------------------------
void AIIC_Send_Memory_Addr(u8 My_Memory_Addr)
{
	u8 Count;
	
	for(Count = 0;Count < 8;Count++)
	{
		if(My_Memory_Addr&0x80)
		{
			SSDA_HIGH;
		}
		else
		{
			SSDA_LOW;
		}
		IIC_RF_DELAY;
		SSCL_HIGH;
		IIC_D_DELAY;
		SSCL_LOW;
		IIC_RF_DELAY;
		My_Memory_Addr <<= 1;
	}
	SSDA_HIGH;
}

//--------------------------------------------------����һ���ֽ�����(���ɵ���ʹ��)------------------------------------------------------
void AIIC_InSendData(u8 My_Data)
{
	u8 Count;
	
	for(Count = 0;Count < 8;Count++)
	{
		if(My_Data&0x80)
		{
			SSDA_HIGH;
		}
		else
		{
			SSDA_LOW;
		}
		IIC_RF_DELAY;
		SSCL_HIGH;
		IIC_D_DELAY;
		SSCL_LOW;
		IIC_RF_DELAY;
		My_Data<<=1;
	}
	SSDA_HIGH;
}

//--------------------------------------------------����һ���ֽ�����(���ɵ���ʹ��)------------------------------------------------------
unsigned char AIIC_InReadData(void)
{
	unsigned char RecData;
	int Count;
	
	SSDA_HIGH;
	RecData = 0;
	for(Count = 8;Count > 0;Count--)
	{
		IIC_RF_DELAY;
		SSCL_HIGH;
		IIC_D_DELAY;
		RecData += (GET_SSDA<<(Count-1));
		SSCL_LOW;
		IIC_RF_DELAY;
	}
	return RecData;
}


//--------------------------------------------------��ʼ��------------------------------------------------------
void AIIC_Init(void)
{
	SSCL_HIGH;
	IIC_D_DELAY;
	SSDA_HIGH;
	IIC_D_DELAY;
}
//--------------------------------------------------����Ӧ��------------------------------------------------------
void AIIC_SendAsk(void)
{
	SSDA_LOW;
	IIC_RF_DELAY;
	SSCL_HIGH;
	IIC_D_DELAY;
	SSCL_LOW;
	IIC_RF_DELAY;
	SSDA_HIGH;
	IIC_RF_DELAY;
}

//--------------------------------------------------дһ���ֽ�����------------------------------------------------------
_Bool AIIC_WriteByte(unsigned char Device_Addr, unsigned char Write_Data)
{
	int ArrayCount;
	
	
	if(AIIC_Reset() == 0)
		return 0;
	AIIC_Init();
	
	//��ʼ��־
	AIIC_Begin_Sign();
	//���͵�ַ
	AIIC_Send_Device_Addr(Device_Addr);
	//дλ
	AIIC_Write_Sign();
	//�ȴ�Ӧ��
	if(AIIC_WriteWaitForAnswer() == 0)
	{
		return 0;
	}
	//����һ���ֽ�����
	AIIC_Send_Memory_Addr(Write_Data);
	//�ȴ�Ӧ��
	if(AIIC_WriteWaitForAnswer() == 0)
	{
		return 0;
	}	
	AIIC_End_Sign();
	return 1;
}


//--------------------------------------------------д��������------------------------------------------------------
_Bool AIIC_WriteDataArray(unsigned char Device_Addr, unsigned char Memory_Addr, unsigned char *DataArray,u16 My_Size)
{
	int ArrayCount;
	
	
	if(AIIC_Reset() == 0)
		return 0;
	AIIC_Init();
	
	//��ʼ��־
	AIIC_Begin_Sign();
	//���͵�ַ
	AIIC_Send_Device_Addr(Device_Addr);
	//дλ
	AIIC_Write_Sign();
	//�ȴ�Ӧ��
	if(AIIC_WriteWaitForAnswer() == 0)
	{
		return 0;
	}
	//�����ڴ��ַ
	AIIC_Send_Memory_Addr(Memory_Addr);
	//�ȴ�Ӧ��
	if(AIIC_WriteWaitForAnswer() == 0)
	{
		return 0;
	}	
	//��������
	for(ArrayCount = 0;ArrayCount < My_Size;ArrayCount++)
	{
		AIIC_InSendData(DataArray[ArrayCount]);
		//�ȴ���Ӧ
		if(AIIC_WriteWaitForAnswer() == 0)
		{
			return 0;
		}
	}
	AIIC_End_Sign();
	return 1;
}

//--------------------------------------------------����������------------------------------------------------------
_Bool AIIC_ReadDataArray(unsigned char Device_Addr, unsigned char Memory_Addr,unsigned char *My_RecDataArray,u16 My_Size)
{
	u8 RecData=0;
	
	u8 Addr_temp=Device_Addr;
	int Count = 0,ArrayCount = 0;
	
	
	
	if(AIIC_Reset() == 0)
		return 0;
	AIIC_Init();

	AIIC_Begin_Sign();
	//���͵�ַ
	AIIC_Send_Device_Addr(Device_Addr);
	//дλ
	AIIC_Write_Sign();
	//�ȴ�Ӧ��
	
	
	if(AIIC_WriteWaitForAnswer() == 0)
	{
		return 0;
	}

	//���ʹ洢����ַ
	AIIC_Send_Memory_Addr(Memory_Addr);
	//�ȴ���Ӧ
	if(AIIC_WriteWaitForAnswer() == 0)
	{
		return 0;
	}
	
	AIIC_Begin_Sign();
	//���͵�ַ
	AIIC_Send_Device_Addr(Addr_temp);
	AIIC_Read_Sign();
	
	AIIC_ReadWaitForAnswer();
	
	for(ArrayCount = 0;ArrayCount < My_Size;ArrayCount++)
	{
		//��������
//		RecData = 0;
//		for(Count = 8;Count > 0;Count--)
//		{
//			IIC_RF_DELAY;
//			SSCL_HIGH;
//			IIC_D_DELAY;
//			RecData += (GET_SSDA<<(Count-1));
//			SSCL_LOW;
//			IIC_RF_DELAY;
//		}
		My_RecDataArray[ArrayCount] = AIIC_InReadData();
		if(ArrayCount >= My_Size-1)
			AIIC_NoAnswer();
		else
			AIIC_SendAsk();
		
	}
	AIIC_End_Sign();
	
	return 1;
}

//--------------------------------------------------��λAIIC------------------------------------------------------
_Bool AIIC_Reset(void)
{
	u16 Count = 0;
	
	SSCL_HIGH;
	IIC_D_DELAY;
	SSDA_HIGH;
	IIC_D_DELAY;
	while(GET_SSDA == 0 && ++Count < 20)
	{
		SSCL_LOW;
		IIC_D_DELAY;
		SSCL_HIGH;
		IIC_D_DELAY;
	}
	if(Count >= 10)
		return 0;
	else
	{
		SSDA_LOW;
		IIC_D_DELAY;
		SSDA_HIGH;
		IIC_D_DELAY;
		return 1;
	}
}
