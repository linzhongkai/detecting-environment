#ifndef HTU2X_H
#define HTU2X_H


#include "stm32f10x.h"

#define HTU2X_TEM 0Xf3 
#define HTU2X_HUM 0xf5


_Bool HTU2X_Init(void);
_Bool HTU2X_Measure(unsigned char Cmd);
unsigned char CommandSend_CRCCal(unsigned char CommandSendAr[], int Length);
float HTU2X_GetTem(void);
float HTU2X_GetHum(void);
void HTU_GPIO_Config(void);


#endif
