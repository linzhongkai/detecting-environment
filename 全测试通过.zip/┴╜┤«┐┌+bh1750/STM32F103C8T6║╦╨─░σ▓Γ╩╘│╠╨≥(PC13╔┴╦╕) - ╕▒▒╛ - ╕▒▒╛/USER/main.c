#include "stm32f10x.h"
#include "GPIOLIKE51.h"
#include "mydelay.h"
#include "usart1.h"
#include "BH1750.h"
#include "usart2.h"
#include "HTU2X.h"
#include "lcd.h"
#include "wifi.h"
#include "bluetooth.h"
#include <stdlib.h>
#include "stdio.h"
#include "string.h"

uchar BUF[8];
int dis_data;
int MCY;
u8 start_sign=0;

int main(void)
{

    float temp, hum, lig;
	u8 temp_str[10];
	u8 hum_str[10];
	u8 lig_str[10];
	u8 wifi_name[100];
	u8 login_str[]="\x17{\"type\":\"pass\",\"data\":{\"id\":\"0000000001\",\"password\":\"NO.1\"}}\x18";
	u8 data[200];
	int flag=1;
	int i,j;

	SystemInit();//��ʼ��ʱ��
	uart_init(9600);//����1��ʼ��	
	usart3_init();//����2��ʼ��
	GPIOConfig();//1750�ܽų�ʼ��	
	Init_BH1750();//BH1750��ʼ��
	HTU_GPIO_Config();
	delay_nms(180);	//��ʱ�ȴ�
	
	//printf("START\r\n\0");//����1����
	
	LCD_Init();
	Lcd_clear();
	LCD_Printf(0, 0, "Test Test Test!!!", COLOR_RED, COLOR_BLACK);
	LCD_Printf(0, 0, "Wait Wifi Connect!!!", COLOR_RED, COLOR_BLACK);
//	LCD_Printf(0, 20, Blue_Array , COLOR_RED, COLOR_BLACK);
	//WIFI_init();
	while(1)
	{
		if(recev_flag==1)
		{
			for(i=0; i<100; i++)
			{
				Blue_Array_name[i]=Blue_Array[i];
				
				
			}
			for(j=99;j<198;j++)
			{
				Blue_Array_pwd[j-99]=Blue_Array[j];	
			}
			
			Lcd_clear();
			//LCD_Printf(0, 20, Blue_Array , COLOR_RED, COLOR_BLACK);		
			//LCD_Printf(0, 50, Blue_Array_pwd , COLOR_RED, COLOR_BLACK);			
			check_wifi(Blue_Array,Blue_Array_pwd);
			
			
			printf("s\r\n");
			break;
			
		}
	}
	
	//Bluetooth_Init();
	//check_blue_connected();
	//send_wifi();
	
	HTU2X_Init();
	printf("Init\r\n");
	
	LCD_Printf(0, 20, "STATUS:", COLOR_RED, COLOR_BLACK);
	LCD_Printf(0, 45, "SEND:", COLOR_RED, COLOR_BLACK);
	LCD_Printf(50, 45, "NONE", COLOR_RED, COLOR_BLACK);
	LCD_Printf(0, 70, "RECE:", COLOR_RED, COLOR_BLACK);
	LCD_Printf(50, 70, "NONE", COLOR_RED, COLOR_BLACK);
	
	
	while(1)
	{
		//UART_PutStr(USART3,"\x17{\"type\":\"login\",\"data\":{\"id\":\"0000000001\",\"password\":\"NO.1\"}}\x18");
		//delay_nms(1000);
//		LCD_Printf(0, 100, Blue_Array, COLOR_RED, COLOR_BLACK);
//		
//		LCD_Printf(0, 125, Blue_Array_pwd, COLOR_RED, COLOR_BLACK);
//		
//		if(start_sign==1)
//		{
//		
		
			//check_blue_connected();
			Single_Write_BH1750(0x01);//power		
			Single_Write_BH1750(0x10);//H		
			delay_nms(180);
			Multiple_Read();
			dis_data=BUF[0];
			dis_data=(dis_data<<8)+BUF[1];
			lig=(float)dis_data/1.2;	
	//		USART_SendData(USART1,temp);
	//		while(USART_GetFlagStatus(USART1,USART_FLAG_TC)==RESET);
	//		printf("\r\n ��ǿ���� %flx\r\n",temp);
	//		
	//		UART_PutStr(USART2,"AT\r\n");
			
			HTU2X_Measure(HTU2X_TEM);
			temp = HTU2X_GetTem();
			hum = HTU2X_GetHum();
			Lcd_clear();
			
			sprintf(temp_str, "%f", temp);  //������123��ӡ��һ���ַ���������s��
			LCD_Printf(0, 50,"TEMP:", COLOR_RED, COLOR_BLACK);
			LCD_Printf(50, 50,temp_str, COLOR_RED, COLOR_BLACK);
			
			sprintf(hum_str, "%f", hum);  //������123��ӡ��һ���ַ���������s��
			LCD_Printf(0, 75,"HUM:", COLOR_RED, COLOR_BLACK);
			LCD_Printf(50, 75,hum_str, COLOR_RED, COLOR_BLACK);
			
			sprintf(lig_str, "%f", lig);  //������123��ӡ��һ���ַ���������s��
			LCD_Printf(0, 100,"LIG:", COLOR_RED, COLOR_BLACK);
			LCD_Printf(50, 100,lig_str, COLOR_RED, COLOR_BLACK);
	//		printf("%4.2f\n", temp);
			delay_nms(1000);
			//printf("\r\n ��ǿ����\r\n");
			
			//UART_PutStr(USART3,"AT\r\n");
			//LCD_WriteBox(50,50,100,100,5,COLOR_RED);
			//LCD_Printf(0,0,"temp:",COLOR_RED, COLOR_WHITE);
			//delay_nms(1000);
			//Lcd_clear();
			//delay_nms(5000);
			//strcat(temp_str,"\r\n\0");
			//Send_TCP("10",temp_str);
			//(23){"type":"mes","data":{"light":15000,"hum":24.9,"tem":12}}(24)
			
			//strcat(hum_str,"\r\n\0");
			//Send_TCP("10",hum_str);
			
			//strcat(lig_str,"\r\n\0");
			//Send_TCP("10",lig_str);
			sprintf(data,"\x17{\"type\":\"mes\",\"data\":{\"light\":%s,\"hum\":%s,\"tem\":%s}}\x18",lig_str,hum_str,temp_str);
			UART_PutStr(USART3,data);
//		}
				
	}
	 
	 
	 
	 
}





