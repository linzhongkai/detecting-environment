#include "stm32f10x.h"
#include <8Bit_RS_WR_RD_CS_RES.h>
#include <delay.h>

u16 Bit8_Temp;
void Bit8_16_Init(void)
{
	Bit8_16_CS_HIGH;
	Bit8_16_RD_HIGH;
	Bit8_16_WR_HIGH;
	Bit8_16_RS_HIGH;
	Bit8_16_Delay;
	
	Bit8_16_RES_LOW;
	Delay_ms(100);
	Bit8_16_RES_HIGH;
	Delay_ms(100);
	
	Bit8_16_CS_LOW;
}

void Bit8_16_Write_Cmd(u8 My_Cmd)
{
	
	//Bit8_16_CS_LOW;
	//Bit8_16_Delay;
	Bit8_16_RS_LOW;
	Bit8_16_Delay;
	
	Bit8_16_Write_Data_Command(My_Cmd);
	Bit8_16_Delay;
	Bit8_16_WR_LOW;
	Bit8_16_Delay;
	Bit8_16_WR_HIGH;
	Bit8_16_Delay;
	
	//Bit8_16_CS_HIGH;
	//Bit8_16_Delay;
}
void Bit8_16_Write_Data(u8 My_Data)
{
	//Bit8_16_CS_LOW;
	//Bit8_16_Delay;
	Bit8_16_RS_HIGH;
	Bit8_16_Delay;
	
	Bit8_16_Write_Data_Command(My_Data);
	Bit8_16_Delay;
	Bit8_16_WR_LOW;
	Bit8_16_Delay;
	Bit8_16_WR_HIGH;
	Bit8_16_Delay;
	
	//Bit8_16_CS_HIGH;
	//Bit8_16_Delay;
}
u8 Bit8_16_Read_Cmd(void)
{
	u8 My_Cmd;
	
	//Bit8_16_CS_LOW;
	//Bit8_16_Delay;
	Bit8_16_RS_HIGH;
	Bit8_16_Delay;
	
	Bit8_16_RD_LOW;
	Bit8_16_Delay;
	My_Cmd = Bit8_16_Read_Data_Command;
	Bit8_16_RD_HIGH;
	Bit8_16_Delay;
	
	//Bit8_16_CS_HIGH;
	//Bit8_16_Delay;
	return My_Cmd;
}
u8 Bit8_16_Read_Data(void)
{
	u8 My_Data;
	
	//Bit8_16_CS_LOW;
	//Bit8_16_Delay;
	Bit8_16_RS_LOW;
	Bit8_16_Delay;
	
	Bit8_16_RD_LOW;
	Bit8_16_Delay;
	My_Data = Bit8_16_Read_Data_Command;
	Bit8_16_RD_HIGH;
	Bit8_16_Delay;
	
	//Bit8_16_CS_HIGH;
	//Bit8_16_Delay;
	return My_Data;
}

