#ifndef _MYDELAY_H
#define _MYDELAY_H
#include "stm32f10x.h"
#include "GPIOLIKE51.h"

void delay_us(void);
void delay_1ms(void);
void delay_nms(u16 time);
void delay_5us(void);

#endif
