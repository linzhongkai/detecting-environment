#ifndef AIIC_H
#define AIIC_H
#include "stm32f10x.h"


//AIIC
_Bool AIIC_ReadWaitForAnswer(void);
_Bool AIIC_WriteWaitForAnswer(void);
_Bool AIIC_Reset(void);
void AIIC_End_Sign(void);
void AIIC_Begin_Sign(void);
void AIIC_Write_Sign(void);
void AIIC_InSendData(u8 My_Data);
void AIIC_SendAsk(void);
_Bool AIIC_WriteData(unsigned char Device_Addr, unsigned char Memory_Addr, unsigned char Data);
_Bool AIIC_WriteDataArray(unsigned char Device_Addr, unsigned char Memory_Addr, unsigned char *DataArray,u16 My_Size);
_Bool AIIC_ReadDataArray(unsigned char Device_Addr, unsigned char Memory_Addr,unsigned char *My_RecDataArray,u16 My_Size);
_Bool AIIC_ReadData(unsigned char Device_Addr, unsigned char Memory_Addr,unsigned char *My_RecData);
void AIIC_Send_Device_Addr(u8 My_Device_Addr);
void AIIC_Send_Memory_Addr(u8 My_Memory_Addr);
void AIIC_Read_Sign(void);
void AIIC_Init(void);
void AIIC_NoAnswer(void);
unsigned char AIIC_InReadData(void);
_Bool AIIC_WriteByte(unsigned char Device_Addr, unsigned char Write_Data);
#define SSCL_HIGH GPIO_SetBits(GPIOB,GPIO_Pin_12);
#define SSCL_LOW GPIO_ResetBits(GPIOB,GPIO_Pin_12);

#define SSDA_HIGH GPIO_SetBits(GPIOB,GPIO_Pin_13);
#define SSDA_LOW GPIO_ResetBits(GPIOB,GPIO_Pin_13);
#define GET_SSDA GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_13)
#define IIC_RF_DELAY Delay_us(30);
#define IIC_D_DELAY Delay_us(60);
#endif
