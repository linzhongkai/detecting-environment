#ifndef _WIFI_H
#define _WIFI_H

#include "stm32f10x.h"

void WIFI_init(void);
void Check_cmd(u8 *command, u8 *output_state, u8 *step);
void Send_TCP(u8 *str_length, u8 *str_array);
int Receive_TCP(u8 *check_array);
void Check_send(u8 *command, u8 *output_state, u8 *str_length);
void check_wifi(u8 *wifi_name, u8 *password);
void send_wifi(void);


extern u8 Array[];
extern u8 Recsign;
extern u8 ArrayIndex;
extern int send_wififlag;

#endif
