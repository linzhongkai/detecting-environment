#ifndef LCD_H
#define LCD_H

#include "stm32f10x.h"
//LCD
#define SHOW_MODE_PORTRAIT 0x00
#define SHOW_MODE_LANDSCAPE 0x20
#define SELECT_SHOW_MODE SHOW_MODE_LANDSCAPE
#define COLOR_RED 0XF800
#define COLOR_GREEN 0X07E0
#define COLOR_BLUE 0X001F
#define COLOR_YELLOW 0XFFE0
#define COLOR_BLACK 0X0000
#define COLOR_WHITE 0XFFFF
#if SELECT_SHOW_MODE == 0
	#define LCD_WIDTH 239
	#define LCD_HIGHT	319
#else
	#define LCD_WIDTH 319
	#define LCD_HIGHT	239
#endif

#define WINDOWS_START_POS_X 159-281/2
#define WINDOWS_START_POS_Y 110-201/2
#define LCD_X_DIVISION 1
#define LCD_Y_DIVISION 25

void LCD_Init(void);
void LCD_SetPos(u16 X_Start,u16 X_End,u16 Y_Start,u16 Y_End);
void LCD_SetPartialAreaPos(u16 Y_Start,u16 Y_End);
void LCD_Mode_PartialArea(void);
void LCD_Mode_Normal(void);
void LCD_WriteLine(u16 X_Pos,u16 Y_Pos,u16 Length,u16 Weith,_Bool Direction,u16 Color);
void LCD_WriteBox(u16 X_Pos,u16 Y_Pos,u16 Width,u16 Hight,u16 LineWidth,u16 Color);
void LCD_WriteDottedLine(u16 X_Pos,u16 Y_Pos,u16 Length,u16 Width,_Bool Direction,u16 Color);
void LCD_Putchar(u16 X_Pos,u16 Y_Pos,char MyChar,u16 CharColor,u16 BGColor);
void LCD_Printf(u16 X_Pos,u16 Y_Pos,char *Sentance,u16 CharColor,u16 BGColor);
void Lcd_clear(void);
#define LCD_SEND_PIXEL(Color) {Bit8_16_Write_Data(((Color))>>8);Bit8_16_Write_Data(((Color))&0x00ff);}


#endif
