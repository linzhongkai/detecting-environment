#include "stm32f10x.h"
#ifndef Bit_RES_RS_WR_RD_CS_H
#define Bit_RES_RS_WR_RD_CS_H
//8Bit_RES_RS_WR_RD_CS

#define SELECT_8BIT_OR_16BIT 0              //�˺궨����ʱ�����ã���Ҫ��һ��16λģʽ����

#define Bit8_16_Data_Command_GPIO GPIOA
#define SELECT_USE_BIT 0x00FF
#define Bit8_16_Read_Data_Command ((GPIO_ReadInputData(Bit8_16_Data_Command_GPIO)&SELECT_USE_BIT))
//#define Bit8_16_Write_Data_Command(x) (GPIO_Write(Bit8_16_Data_Command_GPIO,((GPIO_ReadInputData(Bit8_16_Data_Command_GPIO)&(~SELECT_USE_BIT))|(x)))) 
#define Bit8_16_Write_Data_Command(x) Bit8_16_Data_Command_GPIO ->ODR=(x)

	//RES
//#define Bit8_16_RES_HIGH GPIO_SetBits(GPIOG,GPIO_Pin_0)
//#define Bit8_16_RES_LOW GPIO_ResetBits(GPIOG,GPIO_Pin_0)

#define Bit8_16_RES_HIGH GPIOB->BSRR = GPIO_Pin_0
#define Bit8_16_RES_LOW GPIOB->BRR = GPIO_Pin_0


		//CS
//#define Bit8_16_CS_HIGH GPIO_SetBits(GPIOG,GPIO_Pin_1)
//#define Bit8_16_CS_LOW GPIO_ResetBits(GPIOG,GPIO_Pin_1)

#define Bit8_16_CS_HIGH GPIOB->BSRR = GPIO_Pin_1
#define Bit8_16_CS_LOW GPIOB->BRR = GPIO_Pin_1
		
		//RS
//#define Bit8_16_RS_HIGH GPIO_SetBits(GPIOE,GPIO_Pin_7)
//#define Bit8_16_RS_LOW GPIO_ResetBits(GPIOE,GPIO_Pin_7)

#define Bit8_16_RS_HIGH GPIOB->BSRR = GPIO_Pin_7
#define Bit8_16_RS_LOW GPIOB->BRR = GPIO_Pin_7

		//WR
//#define Bit8_16_WR_HIGH GPIO_SetBits(GPIOE,GPIO_Pin_8)
//#define Bit8_16_WR_LOW GPIO_ResetBits(GPIOE,GPIO_Pin_8)

#define Bit8_16_WR_HIGH GPIOB->BSRR = GPIO_Pin_8
#define Bit8_16_WR_LOW GPIOB->BRR = GPIO_Pin_8

		//RD
//#define Bit8_16_RD_HIGH GPIO_SetBits(GPIOE,GPIO_Pin_9)
//#define Bit8_16_RD_LOW GPIO_ResetBits(GPIOE,GPIO_Pin_9)

#define Bit8_16_RD_HIGH GPIOB->BSRR = GPIO_Pin_9
#define Bit8_16_RD_LOW GPIOB->BRR = GPIO_Pin_9

//#define Bit8_16_Delay Bit8_Temp++;
#define Bit8_16_Delay ;

#define DEF_Bit8_16_Write_Cmd(C) {Bit8_16_RS_LOW;Bit8_16_Delay;Bit8_16_Write_Data_Command((C));Bit8_16_Delay;Bit8_16_Delay;Bit8_16_WR_HIGH;Bit8_16_Delay;}
#define DEF_Bit8_16_Write_Data(D) {Bit8_16_RS_HIGH;Bit8_16_Delay;Bit8_16_Write_Data_Command((D));Bit8_16_Delay;Bit8_16_WR_LOW;Bit8_16_Delay;Bit8_16_WR_HIGH;Bit8_16_Delay;}


void Bit8_16_Init(void);
void Bit8_16_Write_Cmd(u8 My_Cmd);
void Bit8_16_Write_Data(u8 My_Data);
u8 Bit8_16_Read_Cmd(void);
u8 Bit8_16_Read_Data(void);
#endif
