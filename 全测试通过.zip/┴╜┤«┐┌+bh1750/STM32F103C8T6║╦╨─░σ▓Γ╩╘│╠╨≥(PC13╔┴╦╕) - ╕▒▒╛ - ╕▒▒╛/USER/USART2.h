#ifndef _USART2_H
#define _USART2_H
#include "stdio.h"	
#include "stm32f10x.h"
#include "usart1.h"

extern u8 start_sign;
extern u8 arr[];
extern int recev_flag;
void RCC_Config(void);
void GPIO_Config(void);
void USART3_Config(void);
void NVIC_Config(void);
void UART_PutChar(USART_TypeDef* USARTx, uint8_t Data);
void UART_PutStr(USART_TypeDef* USARTx, uint8_t *str);
void usart3_init(void);

#endif

