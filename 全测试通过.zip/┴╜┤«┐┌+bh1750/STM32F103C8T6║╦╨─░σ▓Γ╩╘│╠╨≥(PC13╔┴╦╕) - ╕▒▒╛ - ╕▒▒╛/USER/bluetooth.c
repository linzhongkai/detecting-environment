#include "bluetooth.h"
#include "usart1.h"
#include "wifi.h"
#include "mydelay.h"
#include "lcd.h"
#include "stdio.h"
#include "string.h"

u8 Blue_Array[250];
u8 Blue_Array_name[100];
u8 Blue_Array_pwd[100];
u8 Blue_Recsign=0;
u8 Blue_ArrayIndex=0;
u8 Blue_Array_pwdIndex=0;
int b_t,b_k;

void Bluetooth_Init(void)
{
	//AT����
	Blue_Check_cmd("AT\r\n","OK\r\n", "AT");
	//������������
	Blue_Check_cmd("AT+NAME=Bluetooth-Slave\r\n","OK\r\n","NAME");
	Blue_Check_cmd("AT+ROLE=0\r\n","OK\r\n","ROLE");
	Blue_Check_cmd("AT+CMODE=0\r\n","OK\r\n","MODE");
	Blue_Check_cmd("AT+PSWD=1234\r\n","OK\r\n","PSWD");
	Blue_Check_cmd("AT+UART=9600,0,0\r\n","OK\r\n","UART");
	//Blue_Check_cmd("AT+RMAAD\r\n","OK\r\n","WAIT");
}
	

void Blue_Check_cmd(u8 *command, u8 *output_state, u8 *step)
{
	strncpy(Blue_Array,output_state,strlen(output_state)+1);
	Blue_Recsign = 0;
	Blue_ArrayIndex = 0;
	
	while(1)
	{
		printf(command);
		for(b_t=0;b_t<2000;b_t++)
		{
			delay_nms(10);
			if(Blue_Recsign==1)
			{
				Lcd_clear();
				LCD_Printf(0, 25, "BLUE:", COLOR_RED, COLOR_BLACK);
				LCD_Printf(50, 25, output_state, COLOR_RED, COLOR_BLACK);
				LCD_Printf(150, 25, step, COLOR_RED, COLOR_BLACK);
				break;
			}
		}
		if(Blue_Recsign==0)
		{
			Lcd_clear();
			LCD_Printf(0, 25, "BLUE:", COLOR_RED, COLOR_BLACK);
			LCD_Printf(50, 25, "Falied", COLOR_RED, COLOR_BLACK);
			LCD_Printf(150, 25, step, COLOR_RED, COLOR_BLACK);
			//printf("falied\n");
			continue;
		}
		
		break;
	}
	
}

int check_blue_connected(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_IPU;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_InitStruct.GPIO_Pin=GPIO_Pin_12;
	GPIO_Init(GPIOA,&GPIO_InitStruct);
	GPIO_SetBits(GPIOA,GPIO_Pin_12);
	
	while(1)
	{
		if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_12)==SET)
		{
//			LCD_Printf(0, 0, "WIFI:", COLOR_RED, COLOR_BLACK);
//			LCD_Printf(50, 0, "CONNECTED", COLOR_RED, COLOR_BLACK);
//			LCD_Printf(150, 0, "SUCCESS", COLOR_RED, COLOR_BLACK);
//			
			LCD_Printf(0, 25, "BLUE:", COLOR_RED, COLOR_BLACK);
			LCD_Printf(50, 25, "CONNECTED", COLOR_RED, COLOR_BLACK);
			LCD_Printf(150, 25, "STATE", COLOR_RED, COLOR_BLACK);
			delay_1ms();
			return 1;
		}
		else
		{
			LCD_Printf(0, 25, "BLUE:", COLOR_RED, COLOR_BLACK);
			LCD_Printf(50, 25, "BTLOSTING", COLOR_RED, COLOR_BLACK);
			LCD_Printf(150, 25, "STATE", COLOR_RED, COLOR_BLACK);
		}
	}
}
