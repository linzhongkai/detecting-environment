#include "stm32f10x.h"
#include <delay.h>
void Delay_ms(u32 delay_time)
{
	while(delay_time--)
		Delay_us(1000);
}

void Delay_us(u32 delay_time)
{
	u32 temp;
	
	while(delay_time--)
	{
		__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
		__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
		__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
		__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
		__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
		__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
		__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
		__NOP();__NOP();
	}
}
//void Delay_ms(u32 delay_time)
//{
//	u32 temp,count,temp2,temp3;
//	
//	if(delay_time > 0)
//	{
//		temp2 = delay_time/1000;
//		temp3 = delay_time%1000;
//		for(count = 0;count<temp2;count++)
//		{
//			SysTick->LOAD = 1000*(SystemCoreClock/8000000)*1000;
//			SysTick->VAL = 0;
//			SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;
//			do
//			{
//				temp = SysTick->CTRL;
//			}while((temp&0x01)&&!(temp&(0x01<<16)));
//			SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;
//			SysTick->VAL = 0;
//		}
//		if(temp3>0)
//		{
//			SysTick->LOAD = temp3*(SystemCoreClock/8000000)*1000;
//			SysTick->VAL = 0;
//			SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;
//			do
//			{
//				temp = SysTick->CTRL;
//			}while((temp&0x01)&&!(temp&(0x01<<16)));
//			SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;
//			SysTick->VAL = 0;
//		}
//	}
//}
//void Delay_us(u32 delay_time)
//{
//	u32 temp;
//	
//	SysTick->LOAD = delay_time*(SystemCoreClock/8000000);
//	SysTick->VAL = 0;
//	SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;
//	do
//	{
//		temp = SysTick->CTRL;
//	}while((temp&0x01)&&!(temp&(0x01<<16)));
//	SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;
//	SysTick->VAL = 0;
//}
//void Delay_100us(u32 delay_time)
//{
//	u32 temp;
//	
//	SysTick->LOAD = delay_time*(SystemCoreClock/8000000)*100;
//	SysTick->VAL = 0;
//	SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;
//	do
//	{
//		temp = SysTick->CTRL;
//	}while((temp&0x01)&&!(temp&(0x01<<16)));
//	SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;
//	SysTick->VAL = 0;
//}
