#ifndef _BH1750_H
#define _BH1750_H

#include "stm32f10x.h"

#define uchar unsigned char
#define uint unsigned int

#define sda GPIO_Pin_14
#define scl GPIO_Pin_15

#define SlaveAddress 0x46 //�ӵ�ַ

extern uchar BUF[8];
extern int dis_data;
extern int MCY; //��ʾ��λ��־

void GPIOConfig(void);
void BH1750_Start(void);
void BH1750_Stop(void);
void BH1750_SendAck(int ack);
int BH1750_RecvACK(void);
void BH1750_SendByte(uchar dat);
uchar BH1750_RecvByte(void);
void Single_Write_BH1750(uchar REG_Address);
void Multiple_Read(void);
void Init_BH1750(void);

#endif
