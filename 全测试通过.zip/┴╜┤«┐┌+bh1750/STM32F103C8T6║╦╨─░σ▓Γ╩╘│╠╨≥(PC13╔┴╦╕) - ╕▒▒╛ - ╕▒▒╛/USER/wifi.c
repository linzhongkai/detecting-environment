#include "wifi.h"
#include "usart2.h"
#include "stm32f10x.h"
#include "GPIOLIKE51.h"
#include "usart1.h"
#include "stdio.h"
#include "string.h"
#include "mydelay.h"
#include "lcd.h"

u8 Array[10];
u8 Recsign=0;
u8 ArrayIndex=0;
int t,k;
int send_wififlag=0;


//����WiFi��ʼ��
void WIFI_init(void)
{
	
	delay_nms(200);
	
	Check_cmd("AT\r\n", "OK\r\n", "AT");
	delay_nms(200);
	
	//����wifiģʽ
	Check_cmd("AT+CWMODE=1\r\n", "OK\r\n", "MODE");
	delay_nms(200);

	//����wifi
	Check_cmd("AT+CWJAP_DEF=\"ZK\",\"1234567890\"\r\n", "WIFI GOT IP", "AP");
	delay_nms(200);
	
	//�Ͽ�WiFi
	//delay_nms(3000);
	//Check_cmd("AT+CWQAP\r\n", "OK\r\n", "QAP");
	//delay_nms(3000);
	//Check_cmd("AT+CWJAP_DEF=\"ZK\",\"12345678\"\r\n", "WIFI GOT IP", "AP");
	
	//���ӷ�����
	Check_cmd("AT+CIPSTART=\"TCP\",\"47.107.243.20\",8713\r\n", "CONNECT\r\n", "TCP");
	delay_nms(200);
	
	//�Ͽ�
	//delay_nms(3000);
	//Check_cmd("AT+CIPCLOSE\r\n", "CLOSED\r\n", "QTCP");
	//delay_nms(3000);
	//Check_cmd("AT+CIPSTART=\"TCP\",\"47.107.243.20\",8713\r\n", "CONNECT\r\n", "TCP");
	
	//���״̬
	//delay_nms(3000);
	Check_cmd("AT+CIPSTATUS\r\n", "STATUS:3\r\n", "CTCP");
	delay_nms(200);
	
	//���ͳ�ʼ�����
	Check_cmd("AT+CIPSEND=5\r\n", "OK\r\n", "SNED");
	delay_nms(200);
	UART_PutStr(USART3,"Init\r\n");
	
	Lcd_clear();
	LCD_Printf(0, 0, "WIFI:", COLOR_RED, COLOR_BLACK);
	LCD_Printf(50, 0, "CONNECTED", COLOR_RED, COLOR_BLACK);
	LCD_Printf(150, 0, "SUCCESS", COLOR_RED, COLOR_BLACK);	
}

void Check_cmd(u8 *command, u8 *output_state, u8 *step)
{
	strncpy(Array,output_state,strlen(output_state)+1);
	Recsign = 0;
	ArrayIndex = 0;
	
	while(1)
	{
		UART_PutStr(USART3,command);
		for(t=0;t<2000;t++)
		{
			delay_nms(10);
			if(Recsign==1)
			{
				LCD_Printf(0, 0, "WIFI:", COLOR_RED, COLOR_BLACK);
				LCD_Printf(50, 0, output_state, COLOR_RED, COLOR_BLACK);
				LCD_Printf(150, 0, step, COLOR_RED, COLOR_BLACK);
				break;
			}
		}
		if(Recsign==0)
		{
			LCD_Printf(0, 0, "WIFI:", COLOR_RED, COLOR_BLACK);
			LCD_Printf(50, 0, "Falied", COLOR_RED, COLOR_BLACK);
			LCD_Printf(150, 0, step, COLOR_RED, COLOR_BLACK);
			//printf("falied\n");
			continue;
		}
		
		break;
	}
	
}

void Check_send(u8 *command, u8 *output_state, u8 *str_length)
{
	strncpy(Array,output_state,strlen(output_state)+1);
	Recsign = 0;
	ArrayIndex = 0;
	
	while(1)
	{
		UART_PutStr(USART3,command);
		for(t=0;t<2000;t++)
		{
			delay_nms(10);
			if(Recsign==1)
			{
				//LCD_Printf(150, 125, str_length, COLOR_RED, COLOR_BLACK);
				break;
			}
		}
		if(Recsign==0)
		{

			//LCD_Printf(150, 125, str_length, COLOR_RED, COLOR_BLACK);
			//printf("falied\n");
			continue;
		}
		
		break;
	}
	
}


//�������ݵķ����
void Send_TCP(u8 *str_length, u8 *str_array)
{
	u8 temp_array[20]="AT+CIPSEND=";
	strcat(temp_array,str_length);
	strcat(temp_array,"\r\n\0");
	//printf("%s",temp_array);
	Check_send(temp_array, "OK\r\n", str_length);
	strncpy(Array,"SEND OK\r\n",strlen("SEND OK\r\n")+1);//�ж�����
	Recsign = 0;
	ArrayIndex = 0;
	
	UART_PutStr(USART3,str_array);//�ǵô��س�;
	for(t=0;t<2000;t++)
	{
		delay_nms(10);
		if(Recsign==1)
		{
			LCD_Printf(0, 125, "SEND:", COLOR_RED, COLOR_BLACK);
			//LCD_Printf(50, 125, str_array, COLOR_RED, COLOR_BLACK);
			LCD_Printf(50, 125, "LENG", COLOR_RED, COLOR_BLACK);
			LCD_Printf(100, 125, "0", COLOR_RED, COLOR_BLACK);		
			delay_nms(100);
			LCD_Printf(50, 125, "LENG", COLOR_RED, COLOR_BLACK);
			LCD_Printf(100, 125, str_length, COLOR_RED, COLOR_BLACK);
			
			break;
		}
	}
	if(Recsign==0)
	{
		LCD_Printf(0, 125, "SEND:", COLOR_RED, COLOR_BLACK);
		LCD_Printf(50, 125, "Falied", COLOR_RED, COLOR_BLACK);
	}
	
}
	
//��������˵�����
int Receive_TCP(u8 *check_array)
{
	strncpy(Array,check_array,strlen(check_array)+1);//�ж�����
	Recsign = 0;
	ArrayIndex = 0;
	
	for(t=0;t<100;t++)
	{
		delay_nms(10);
		if(Recsign==1)//������ȷ
		{
			LCD_Printf(0, 150, "RECE:", COLOR_RED, COLOR_BLACK);
			LCD_Printf(50, 150, check_array, COLOR_RED, COLOR_BLACK);
			return 1;
		}
	}
	if(Recsign==0)
	{
		LCD_Printf(0, 150, "RECE:", COLOR_RED, COLOR_BLACK);
		LCD_Printf(50, 150, "NONE", COLOR_RED, COLOR_BLACK);
		delay_nms(100);		
		LCD_Printf(50, 150, "WAIT", COLOR_RED, COLOR_BLACK);
	}
		
	return 0;
}

//�����ȵ����Ƶ�app��
void send_wifi(void)
{

}

//����WiFi
//����WiFi��ʼ��
void check_wifi(u8 *wifi_name, u8 *password)
{

	u8 wifi_name_array[100]="AT+CWJAP_DEF=";
	u8 wifi_password[100];


	strcat(wifi_name_array,"\"");
	strcat(wifi_name_array,wifi_name);

	strcat(wifi_name_array,"\"");
	strcat(wifi_name_array,",");

	
	strcat(wifi_password,"\"");
	strcat(wifi_password,password);

	strcat(wifi_password,"\"");
	strcat(wifi_password,"\r\n\0");	
	
	strcat(wifi_name_array,wifi_password);

	
	delay_nms(200);
	
	//Check_cmd("AT\r\n", "OK\r\n", "AT");
	//delay_nms(200);
	
	Check_cmd("AT+RESTORE\r\n", "ready\r\n", "ready");
	delay_nms(200);
	
	//����wifiģʽ
	Check_cmd("AT+CWMODE=1\r\n", "OK\r\n", "MODE");
	delay_nms(200);
	Check_cmd("AT+RST\r\n", "ready\r\n", "ready");
	delay_nms(200);
	
	//����wifi
	
	Check_cmd(wifi_name_array, "WIFI GOT IP", "AP");
	delay_nms(200);
	
	
	
	//���ӷ�����
	Check_cmd("AT+CIPSTART=\"TCP\",\"47.107.243.20\",8716\r\n", "\x17Login...\x18", "TCP");
	delay_nms(200);
	
	
	//���״̬
	//delay_nms(3000);
	//Check_cmd("AT+CIPSTATUS\r\n", "STATUS:3\r\n", "CTCP");
	//delay_nms(200);
	
	//͸��ģʽ
	Check_cmd("AT+CIPMODE=1\r\n", "OK\r\n", "SNED");
	delay_nms(200);
	//���ͳ�ʼ�����
	Check_cmd("AT+CIPSEND\r\n", "OK\r\n", "CIPSNED");
	delay_nms(200);
	
	Check_cmd("\x17{\"type\":\"login\",\"data\":{\"id\":\"0000000001\",\"password\":\"NO.1\"}}\x18","\x17Pass....\x18","LOGIN");
	
	Lcd_clear();
	LCD_Printf(0, 0, "WIFI:", COLOR_RED, COLOR_BLACK);
	LCD_Printf(50, 0, "CONNECTED", COLOR_RED, COLOR_BLACK);
	LCD_Printf(150, 0, "SUCCESS", COLOR_RED, COLOR_BLACK);	
//	LCD_Printf(0, 16, " TCP:", COLOR_RED, COLOR_BLACK);
//	LCD_Printf(50, 16, "CONNECTED", COLOR_RED, COLOR_BLACK);
//	LCD_Printf(150, 16, "SUCCESS", COLOR_RED, COLOR_BLACK);

}
