#ifndef _BLUETOOTH_H
#define _BLUETOOTH_H

#include "stm32f10x.h"

extern u8 Blue_Array[250];
extern u8 Blue_Array_name[100];
extern u8 Blue_Array_pwd[100];
extern u8 Blue_Recsign;
extern u8 Blue_ArrayIndex;
extern u8 Blue_Array_pwdIndex;

void Bluetooth_Init(void);
void Blue_Check_cmd(u8 *command, u8 *output_state, u8 *step);
int check_blue_connected(void);

#endif
