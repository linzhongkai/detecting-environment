#include "HTU2X.h"
#include "aiic.h"
#include "delay.h"


static unsigned char GetData[3] = {0};


_Bool HTU2X_Init(void)
{
	if(AIIC_WriteByte(0X40,0XFE))
	{
		Delay_ms(16);
		return 1;
	}
	return 0;
}

float HTU2X_GetTem(void)
{
	return (float)((((u16)GetData[0])<<8)|((u16)GetData[1]))/65536.0*175.72-46.85;
}

float HTU2X_GetHum(void)
{
	return (float)((((u16)GetData[0])<<8)|((u16)GetData[1]))/65536.0*125.0-6.0;
}

_Bool HTU2X_Measure(unsigned char Cmd)
{
	int OverTime = 0;
	
	if(AIIC_Reset() == 0)
		return 0;
	AIIC_Init();
	
	//��ʼ��־
	AIIC_Begin_Sign();
	
		//���͵�ַ
	AIIC_Send_Device_Addr(0x40);
	
	//дλ
	AIIC_Write_Sign();
	
	//�ȴ�Ӧ��
	if(AIIC_WriteWaitForAnswer() == 0)
	{
		return 0;
	}
	
	//��������
	AIIC_Send_Memory_Addr(Cmd);
	
	//�ȴ�Ӧ��
	if(AIIC_WriteWaitForAnswer() == 0)
	{
		return 0;
	}
	OverTime = 0;
	do
	{
		Delay_ms(1);
		//��ʼ��־
		AIIC_Begin_Sign();
		
		//���͵�ַ
		AIIC_Send_Device_Addr(0x40);
		
		//��λ
		AIIC_Read_Sign();
		OverTime++;
	}while(AIIC_ReadWaitForAnswer()==0 && OverTime <= 50);
	
	if(OverTime > 50)
		return 0;
	
	GetData[0] = AIIC_InReadData();
	AIIC_SendAsk();
	GetData[1] = AIIC_InReadData();
	AIIC_SendAsk();
	GetData[2] = AIIC_InReadData();

	AIIC_NoAnswer();
	AIIC_End_Sign();
	
	if(CommandSend_CRCCal(GetData,2)==GetData[2])
		return 1;
	else
		return 0;
}

unsigned char CommandSend_CRCCal(unsigned char CommandSendAr[], int Length)
{
    unsigned char CRC_8_Value;
    int Count1, Count2;

    CRC_8_Value = 0x00;
    for(Count1 = 0; Count1 < Length; Count1++)
    {
        CRC_8_Value ^= CommandSendAr[Count1];
        for(Count2 = 0; Count2 < 8; Count2++)
        {
            if(CRC_8_Value & 0x80)
                CRC_8_Value = (CRC_8_Value << 1) ^ 0x31;
            else
                CRC_8_Value = (CRC_8_Value << 1);
        }
    }
    return CRC_8_Value^0x00;
}

void HTU_GPIO_Config(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_InitStruct.GPIO_Pin=GPIO_Pin_12;
	
	GPIO_Init(GPIOB,&GPIO_InitStruct);
	
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_Out_OD;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_InitStruct.GPIO_Pin=GPIO_Pin_13;
	
	GPIO_Init(GPIOB,&GPIO_InitStruct);

}

